using MovieDBRestSharp;
using System.Net;

namespace APITests
{
    public class BreakingBadTestCases
    {
        [Test]
        public void ValidateSeasonEpisodeCount()
        {
            int show = 1396; //Breaking Bad Show Id
            var expectedSeasonEpisodeCount = new Dictionary<int, int>
            {
                { 1, 7 }, { 2, 13 }, { 3, 13 }, { 4, 13 }, { 5, 16 }
            };

            var api = new MovieDBTestMethods();
            var response = api.GetSeasonDetails(show);

            for (var i = 1; i < response.seasons.Count(); i++)
            {
                Console.WriteLine(String.Format("Breaking Bad season {0} expected Episode count: {1} and actual Episode count: {2}", i, expectedSeasonEpisodeCount[i], response.seasons[i].episode_count));
                Assert.True(response.seasons[i].episode_count.Equals(expectedSeasonEpisodeCount[i]));
            }
        }
    }
}