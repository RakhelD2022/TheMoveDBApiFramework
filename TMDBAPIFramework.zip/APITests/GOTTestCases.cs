using MovieDBRestSharp;
using System.Net;

namespace APITests
{
    public class GOTTestCases
    {
        [Test]
        public void ValidateActorPresent()
        {
            int show = 1399; //Game Of Thrones Show Id
            int expectedSeasonNumber = 5;
            int expectedEpisodeNumber = 2;
            string expectedCharacterName = "Myrcella Baratheon";
            string expectedOriginalName = "Nell Tiger Free";

            int actualSeasonNumber = 0;
            int actualEpisodeNumber = 0;
            string actualCharacterName = String.Empty;
            string actualOriginalName = String.Empty;

            var api = new MovieDBTestMethods();
            var response = api.GetEpisodeDetails(show, expectedSeasonNumber);
            bool detailsFound = false;

            foreach (var episode in response.episodes)
            {
                actualSeasonNumber = episode.season_number;
                actualEpisodeNumber = episode.episode_number;
                if(expectedSeasonNumber.Equals(actualSeasonNumber) && expectedEpisodeNumber.Equals(actualEpisodeNumber))
                {
                    foreach (var guestStar in episode.guest_stars)
                    {
                        actualCharacterName = guestStar.character;
                        actualOriginalName = guestStar.original_name;
                        Assert.True(expectedCharacterName.Equals(actualCharacterName) && expectedOriginalName.Equals(actualOriginalName));
                        detailsFound = true;
                        break;
                    }
                }
                if(detailsFound)
                {
                    break;
                }
            }
            Console.WriteLine(String.Format("Season validation Expected : {0} Actual: {1}", expectedSeasonNumber, actualSeasonNumber));
            Console.WriteLine(String.Format("Episode validation Expected : {0} Actual: {1}", expectedEpisodeNumber, actualEpisodeNumber));
            Console.WriteLine(String.Format("Character name validation Expected : {0} Actual: {1}", expectedCharacterName, actualCharacterName));
            Console.WriteLine(String.Format("Name validation Expected : {0} Actual: {1}", expectedOriginalName, actualOriginalName));
            Assert.True(detailsFound);
        }

        [Test]
        public void ValidateActorIsNotPresent()
        {
            int show = 1399; //Game Of Thrones Show Id
            int expectedSeasonNumber = 5;
            int expectedEpisodeNumber = 1;
            string expectedCharacterName = "Myrcella Baratheon";
            string expectedOriginalName = "Nell Tiger Free";

            int actualSeasonNumber = 0;
            int actualEpisodeNumber = 0;
            string actualCharacterName = String.Empty;
            string actualOriginalName = String.Empty;

            var api = new MovieDBTestMethods();
            var response = api.GetEpisodeDetails(show, expectedSeasonNumber);
            bool detailsNotFound = false;

            foreach (var episode in response.episodes)
            {
                actualSeasonNumber = episode.season_number;
                actualEpisodeNumber = episode.episode_number;
                if (expectedSeasonNumber.Equals(actualSeasonNumber) && expectedEpisodeNumber.Equals(actualEpisodeNumber))
                {
                    foreach (var guestStar in episode.guest_stars)
                    {
                        actualCharacterName = guestStar.character;
                        actualOriginalName = guestStar.original_name;
                        Assert.False(expectedCharacterName.Equals(actualCharacterName) && expectedOriginalName.Equals(actualOriginalName));
                        detailsNotFound = true;
                        Console.WriteLine("For id " + guestStar.id);
                        Console.WriteLine(String.Format("Character name validation Expected : {0} Actual: {1}", expectedCharacterName, actualCharacterName));
                        Console.WriteLine(String.Format("Name validation Expected : {0} Actual: {1}", expectedOriginalName, actualOriginalName));
                    }
                }
            }
            Console.WriteLine(String.Format("Season validation Expected : {0} Actual: {1}", expectedSeasonNumber, actualSeasonNumber));
            Console.WriteLine(String.Format("Episode validation Expected : {0} Actual: {1}", expectedEpisodeNumber, actualEpisodeNumber));
            Assert.True(detailsNotFound);
        }
    }
}