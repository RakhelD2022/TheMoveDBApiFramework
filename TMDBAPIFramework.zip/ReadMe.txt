1. Please make sure the vesrions of Visual studio and packages is matching as per the file VersionDetails.txt.
2. Steps to execute test cases:
    a. Open extracted folder and Navigate to "MovieDBAPITesting" folder.
    b. Double click on the file "MovieDBAPITesting.sln" to launch the project.
    c. Build the project.
    d. Click on "Test" in menubar of Visual Studio -> Test Explorer
    e. Right click on TestCases. Click on Run.
3. In cases the project is not running please refer Screenshot folders for output in my local system.

Clarifications:
4. For Scenario 2 in first test cases (GOT), I had to validate if the respective actor is present in the main cast. But in the API response there is no attribute for main_cast or anything similar.
5. I had to create two test cases for Game of Thrones scenarios, as both the scenarios are covering two different functionalities.
6. In the Breaking Bad Season 1, there are only 7 episodes but in problem statement it's mentioned as 8. I created the test cases for 7 episodes, to make the test cases pass.

7. I tried my best to keep the logic less complex as there are lot of for loops required for iteration through json response to validate the correct output. 
8. At last a small request, please share your valuable feedback and scope of improvements, even if the framework in not as per your expectation. It will definitely help me in future.
