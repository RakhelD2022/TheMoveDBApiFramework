﻿using MovieDBRestSharp.Models;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieDBRestSharp
{
    public class MovieDBTestMethods
    {
        public SeasonEpisodes GetEpisodeDetails(int show, int season)
        {
            var helper = new Helper();
            var client = helper.SetUrl(String.Format("tv/{0}/season/{1}?api_key=e825dad46ccb24bc8d8e6f4bbf66beb8", show, season));
            var request = helper.CreateGetRequest();
            request.RequestFormat = DataFormat.Json;
            var response = helper.GetResponse(client, request);
            var seasonEpisodes = helper.GetContent<SeasonEpisodes>(response);
            return seasonEpisodes;
        }

        public ShowDetails GetSeasonDetails(int show)
        {
            var helper = new Helper();
            var client = helper.SetUrl(String.Format("tv/{0}?api_key=e825dad46ccb24bc8d8e6f4bbf66beb8", show));
            var request = helper.CreateGetRequest();
            request.RequestFormat = DataFormat.Json;
            var response = helper.GetResponse(client, request);
            var showDetails = helper.GetContent<ShowDetails>(response);
            return showDetails;
        }
    }
}
